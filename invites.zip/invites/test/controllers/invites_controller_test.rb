require 'test_helper'

class InvitesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
