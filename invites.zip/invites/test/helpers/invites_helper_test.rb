require 'test_helper'

class InvitesHelperTest < ActionView::TestCase
end
